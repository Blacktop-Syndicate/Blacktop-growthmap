BLACKTOP GROWTHMAP - FRESH COMPLETE WORKING WEBSITE

This is a fresh complete Next.js website.

CONFIRMED FEATURES:
- The questionnaire is hidden by default.
- The questionnaire opens only when clicking:
  1. Open Questionnaire
  2. Start Questionnaire
  3. Open App Questionnaire
- The questionnaire does NOT block the whole site unless opened.
- The questionnaire header does NOT say BS.
- Hero badge says: Powered by Blacktop AI
- Brain icon is used beside Powered by Blacktop AI.
- Includes complete app/page.tsx, layout, Tailwind, button/card components, package.json.

HOW TO DEPLOY:
1. Create a brand new GitHub repository.
2. Upload everything inside this folder.
3. Go to Vercel.
4. Import the new repository.
5. Deploy.
6. Open the Vercel URL in an incognito tab to avoid cached old versions.
