"use client";

import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  BarChart3,
  Bot,
  Brain,
  CheckCircle2,
  Clipboard,
  Cpu,
  FileText,
  Lock,
  Map,
  Megaphone,
  ShieldCheck,
  Target,
  TrendingUp,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const industries = [
  "Trucking / Logistics",
  "Diesel Shop / Auto Repair",
  "Restaurant / Bar",
  "Tattoo Shop",
  "Gym / Fitness",
  "Construction / Contractor",
  "Roofing / HVAC",
  "Barbershop / Salon",
  "Retail / Apparel",
  "Sports / Entertainment",
  "Other"
];

const socialStatuses = [
  "Posts consistently",
  "Posts sometimes",
  "Rarely posts",
  "No real social presence"
];

const goals = [
  "More calls",
  "More leads",
  "More walk-in traffic",
  "More booked appointments",
  "More online sales",
  "Brand awareness"
];

const services = [
  "Weekly Reels",
  "Social Management",
  "Local Ads",
  "Google Business Profile Optimization",
  "Monthly Reporting"
];

const featureCards = [
  {
    icon: Bot,
    title: "AI-Powered",
    text: "Smart audits that uncover missed growth opportunities fast."
  },
  {
    icon: BarChart3,
    title: "Data-Driven",
    text: "Scoring built around website, social, content, and ad readiness."
  },
  {
    icon: Target,
    title: "Results-Focused",
    text: "Built to create more calls, leads, appointments, and sales."
  },
  {
    icon: ShieldCheck,
    title: "Built To Win",
    text: "Road-tested strategy for real businesses that need traction."
  }
];

function ScoreRing({ score }: { score: number | null }) {
  const display = score === null ? "--" : score;
  const pct = score === null ? 0 : score;

  return (
    <div className="relative grid h-44 w-44 place-items-center rounded-full bg-slate-950 shadow-[0_0_60px_rgba(34,211,238,.12)]">
      <div
        className="absolute inset-0 rounded-full"
        style={{
          background: `conic-gradient(rgb(103 232 249) ${pct}%, rgba(255,255,255,.08) ${pct}%)`
        }}
      />
      <div className="absolute inset-3 rounded-full bg-black" />
      <div className="relative text-center">
        <div className="text-5xl font-black text-white">{display}</div>
        <div className="text-sm font-bold uppercase tracking-[0.25em] text-cyan-200">
          /100
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  children
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-bold text-slate-200">
        {label}
      </span>
      {children}
    </label>
  );
}

function inputClass() {
  return "w-full rounded-2xl border border-white/10 bg-black/60 px-4 py-3 text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-300/70 focus:ring-2 focus:ring-cyan-300/15";
}

export default function BlacktopGrowthMapSite() {
  const [form, setForm] = useState({
    businessName: "",
    industry: "Trucking / Logistics",
    website: "",
    socialStatus: "Posts sometimes",
    shortVideo: "Yes",
    paidAds: "No",
    goal: "More calls",
    notes: ""
  });

  const [generated, setGenerated] = useState(false);
  const [questionnaireOpen, setQuestionnaireOpen] = useState(false);

  const score = useMemo(() => {
    if (!generated) return null;

    let total = 48;
    if (form.website.trim()) total += 12;
    if (form.socialStatus === "Posts consistently") total += 18;
    if (form.socialStatus === "Posts sometimes") total += 10;
    if (form.shortVideo === "Yes") total += 12;
    if (form.paidAds === "Yes") total += 10;

    return Math.min(total, 96);
  }, [generated, form]);

  const subScores = useMemo(() => {
    if (!generated) {
      return [
        ["Website", null],
        ["Social", null],
        ["Content", null],
        ["Ad Readiness", null]
      ] as const;
    }

    return [
      ["Website", form.website ? 82 : 55],
      [
        "Social",
        form.socialStatus === "Posts consistently"
          ? 88
          : form.socialStatus === "Posts sometimes"
          ? 68
          : 44
      ],
      ["Content", form.shortVideo === "Yes" ? 84 : 52],
      ["Ad Readiness", form.paidAds === "Yes" ? 78 : 48]
    ] as const;
  }, [generated, form]);

  const packageName =
    score === null
      ? "Suggested Package"
      : score >= 82
      ? "Scale Route"
      : score >= 65
      ? "Growth Route"
      : "Foundation Route";

  const recommendations = generated
    ? [
        `Build the next 30 days around ${form.goal.toLowerCase()} with one clear offer and one main call-to-action.`,
        form.shortVideo === "Yes"
          ? "Increase short-form video volume and repurpose each reel into Facebook, Instagram, and Google Business Profile posts."
          : "Add weekly short-form videos so the business has stronger reach and retargeting content.",
        form.paidAds === "Yes"
          ? "Tighten paid ads around one offer, one landing page, and tracked call or lead conversion."
          : "Start with a small local ad test after the website and social proof are cleaned up."
      ]
    : ["Your recommendations will appear here after the questionnaire is completed."];

  const reportText = generated
    ? `BLACKTOP GROWTHMAP AUDIT\n\nBusiness: ${
        form.businessName || "Business Name"
      }\nIndustry: ${form.industry}\nMain Goal: ${
        form.goal
      }\n\nGrowth Score: ${score}/100\nSuggested Route: ${packageName}\n\nRecommended Growth Route:\n- ${recommendations.join(
        "\n- "
      )}\n\nRecommended Services:\n- ${services.join(
        "\n- "
      )}\n\nBuilt by Blacktop GrowthMap™. Powered by Blacktop AI.`
    : "Your detailed GrowthMap report will appear here after you open and complete the questionnaire.";

  const handleChange = (key: keyof typeof form, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const copyReport = async () => {
    try {
      await navigator.clipboard.writeText(reportText);
      alert("GrowthMap copied.");
    } catch {
      alert("Copy failed. You can manually highlight and copy the report.");
    }
  };

  const finishQuestionnaire = () => {
    setGenerated(true);
    setQuestionnaireOpen(false);
    setTimeout(() => {
      document.getElementById("results")?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  return (
    <main className="min-h-screen bg-black text-white">
      <section className="relative overflow-hidden border-b border-white/10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(34,211,238,.16),transparent_28%),radial-gradient(circle_at_80%_10%,rgba(16,185,129,.13),transparent_24%),linear-gradient(to_bottom,rgba(2,6,23,.4),#000)]" />

        <div className="absolute inset-0 opacity-25">
          <svg viewBox="0 0 1200 700" className="h-full w-full" preserveAspectRatio="none">
            {Array.from({ length: 22 }).map((_, i) => (
              <path
                key={i}
                d={`M0 ${60 + i * 28} H${220 + (i % 6) * 90} V${95 + i * 28} H1200`}
                fill="none"
                stroke="rgb(103 232 249)"
                strokeWidth="1"
              />
            ))}
            {Array.from({ length: 38 }).map((_, i) => (
              <circle
                key={i}
                cx={(i * 97) % 1200}
                cy={60 + ((i * 53) % 560)}
                r="3"
                fill="rgb(110 231 183)"
              />
            ))}
          </svg>
        </div>

        <div className="relative mx-auto max-w-7xl px-5 py-6 md:px-8">
          <header className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="grid h-12 w-12 place-items-center rounded-2xl border border-cyan-300/40 bg-black/70 shadow-[0_0_35px_rgba(34,211,238,.2)]">
                <Cpu className="h-6 w-6 text-cyan-200" />
              </div>
              <div>
                <div className="text-sm font-bold uppercase tracking-[0.32em] text-cyan-200">
                  Blacktop Syndicate
                </div>
                <div className="text-xl font-black tracking-tight text-white">
                  GrowthMap™
                </div>
              </div>
            </div>

            <Button
              onClick={() => setQuestionnaireOpen(true)}
              className="hidden rounded-2xl bg-cyan-300 font-black text-black hover:bg-cyan-200 md:inline-flex"
            >
              Open Questionnaire <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </header>

          <div className="grid gap-10 pb-14 pt-16 md:grid-cols-[1.05fr_.95fr] md:items-center md:pt-24">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-cyan-300/25 bg-cyan-300/10 px-4 py-2 text-sm font-semibold text-cyan-100">
                <Brain className="h-4 w-4" /> Powered by Blacktop AI
              </div>

              <h1 className="max-w-4xl text-5xl font-black leading-[0.95] tracking-tight md:text-7xl">
                Systems. Content. Growth.
                <span className="block text-cyan-200">Built for the road ahead.</span>
              </h1>

              <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300">
                Get an instant AI-powered business audit with a custom GrowthMap for leads, content, ads, and revenue.
              </p>

              <div className="mt-8 flex flex-col gap-4 sm:flex-row">
                <Button
                  onClick={() => setQuestionnaireOpen(true)}
                  className="rounded-2xl bg-cyan-300 px-8 py-6 text-base font-black text-black hover:bg-cyan-200"
                >
                  Start Questionnaire <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <a href="#results">
                  <Button
                    variant="outline"
                    className="rounded-2xl border-white/15 bg-black/40 px-8 py-6 text-base font-bold text-white hover:bg-white/10"
                  >
                    View GrowthMap
                  </Button>
                </a>
              </div>
            </motion.div>

            <Card className="rounded-[2rem] border-white/10 bg-black/65 shadow-2xl backdrop-blur-xl">
              <CardContent className="p-6 md:p-8">
                <div className="mb-6 flex items-center gap-3">
                  <Map className="h-7 w-7 text-emerald-300" />
                  <div>
                    <h2 className="text-2xl font-black text-white">GrowthMap Snapshot</h2>
                    <p className="text-sm text-slate-400">
                      Click the questionnaire to unlock your audit.
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  {["Business intake", "AI scoring", "Growth route", "Copy-ready report"].map((item, index) => (
                    <div key={item} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] p-4">
                      <div className="grid h-9 w-9 place-items-center rounded-xl bg-cyan-300/10 text-sm font-black text-cyan-200">
                        {index + 1}
                      </div>
                      <span className="font-bold text-slate-100">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="px-5 py-16 md:px-8">
        <div className="mx-auto max-w-7xl">
          <Card className="rounded-[2rem] border-cyan-300/20 bg-cyan-300/[0.05]">
            <CardContent className="grid gap-8 p-6 md:grid-cols-[1fr_auto] md:items-center md:p-8">
              <div>
                <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-300/25 bg-black/40 px-4 py-2 text-sm font-bold text-cyan-100">
                  <Brain className="h-4 w-4" /> Powered by Blacktop AI
                </div>
                <h2 className="text-4xl font-black text-white">App Questionnaire</h2>
                <p className="mt-3 max-w-2xl text-lg leading-8 text-slate-300">
                  The questionnaire stays closed until clicked. Open it, answer a few questions, and generate your GrowthMap report.
                </p>
              </div>

              <Button
                onClick={() => setQuestionnaireOpen(true)}
                className="rounded-2xl bg-cyan-300 px-8 py-6 text-base font-black text-black hover:bg-cyan-200"
              >
                Open App Questionnaire <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {questionnaireOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 px-4 py-6 backdrop-blur-md">
          <div className="mx-auto max-w-6xl">
            <div className="mb-4 flex justify-end">
              <Button
                onClick={() => setQuestionnaireOpen(false)}
                variant="outline"
                className="rounded-2xl border-white/15 bg-black/70 px-5 font-bold text-white hover:bg-white/10"
              >
                <X className="mr-2 h-4 w-4" /> Close
              </Button>
            </div>

            <div className="grid gap-6 lg:grid-cols-[1fr_.9fr]">
              <Card className="rounded-[2rem] border-white/10 bg-slate-950 shadow-2xl">
                <CardContent className="p-6 md:p-8">
                  <div className="mb-7">
                    <h2 className="text-3xl font-black text-white">Business Intake</h2>
                    <p className="mt-2 text-slate-400">
                      Answer these questions to generate the GrowthMap.
                    </p>
                  </div>

                  <div className="grid gap-5 md:grid-cols-2">
                    <Field label="Business Name">
                      <input
                        className={inputClass()}
                        placeholder="Example: Blacktop Diesel Co."
                        value={form.businessName}
                        onChange={(e) => handleChange("businessName", e.target.value)}
                      />
                    </Field>

                    <Field label="Industry">
                      <select
                        className={inputClass()}
                        value={form.industry}
                        onChange={(e) => handleChange("industry", e.target.value)}
                      >
                        {industries.map((item) => (
                          <option key={item}>{item}</option>
                        ))}
                      </select>
                    </Field>

                    <Field label="Website">
                      <input
                        className={inputClass()}
                        placeholder="https://yourwebsite.com"
                        value={form.website}
                        onChange={(e) => handleChange("website", e.target.value)}
                      />
                    </Field>

                    <Field label="Social Media Status">
                      <select
                        className={inputClass()}
                        value={form.socialStatus}
                        onChange={(e) => handleChange("socialStatus", e.target.value)}
                      >
                        {socialStatuses.map((item) => (
                          <option key={item}>{item}</option>
                        ))}
                      </select>
                    </Field>

                    <Field label="Uses Reels / Short Videos?">
                      <select
                        className={inputClass()}
                        value={form.shortVideo}
                        onChange={(e) => handleChange("shortVideo", e.target.value)}
                      >
                        <option>Yes</option>
                        <option>No</option>
                      </select>
                    </Field>

                    <Field label="Runs Paid Ads?">
                      <select
                        className={inputClass()}
                        value={form.paidAds}
                        onChange={(e) => handleChange("paidAds", e.target.value)}
                      >
                        <option>No</option>
                        <option>Yes</option>
                      </select>
                    </Field>

                    <Field label="Main Goal">
                      <select
                        className={inputClass()}
                        value={form.goal}
                        onChange={(e) => handleChange("goal", e.target.value)}
                      >
                        {goals.map((item) => (
                          <option key={item}>{item}</option>
                        ))}
                      </select>
                    </Field>

                    <Field label="Notes">
                      <input
                        className={inputClass()}
                        placeholder="Anything important we should know?"
                        value={form.notes}
                        onChange={(e) => handleChange("notes", e.target.value)}
                      />
                    </Field>
                  </div>

                  <div className="mt-7 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center gap-2 text-sm text-slate-400">
                      <Lock className="h-4 w-4 text-emerald-300" /> Your information is secure and never shared.
                    </div>

                    <Button
                      onClick={finishQuestionnaire}
                      className="rounded-2xl bg-cyan-300 px-7 py-6 font-black text-black hover:bg-cyan-200"
                    >
                      Generate GrowthMap <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="rounded-[2rem] border-white/10 bg-slate-950 shadow-2xl">
                <CardContent className="p-6 md:p-8">
                  <div className="mb-6 flex items-center gap-3">
                    <TrendingUp className="h-7 w-7 text-emerald-300" />
                    <div>
                      <h2 className="text-3xl font-black text-white">Growth Preview</h2>
                      <p className="text-slate-400">
                        Your score appears after generating.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-center py-3">
                    <ScoreRing score={score} />
                  </div>

                  <div className="mt-6 grid gap-3 sm:grid-cols-2">
                    {subScores.map(([label, value]) => (
                      <div key={label} className="rounded-2xl border border-white/10 bg-black/40 p-4">
                        <div className="text-sm text-slate-400">{label}</div>
                        <div className="mt-1 text-2xl font-black text-white">
                          {value === null ? "--" : value}
                          <span className="text-sm text-slate-500">/100</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      )}

      <section id="results" className="px-5 pb-16 md:px-8">
        <div className="mx-auto grid max-w-7xl gap-6 lg:grid-cols-[.9fr_1.1fr]">
          <Card className="rounded-[2rem] border-cyan-300/20 bg-cyan-300/[0.05]">
            <CardContent className="p-6 md:p-8">
              <div className="mb-5 flex items-center gap-3">
                <Megaphone className="h-7 w-7 text-cyan-300" />
                <h2 className="text-3xl font-black text-white">Recommended Growth Route</h2>
              </div>

              <div className="space-y-3">
                {recommendations.map((item) => (
                  <div key={item} className="flex gap-3 rounded-2xl bg-black/35 p-4 text-slate-200">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-300" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              <div className="mt-7 rounded-2xl border border-white/10 bg-black/45 p-5">
                <div className="text-sm font-bold uppercase tracking-[0.25em] text-cyan-200">
                  Suggested Package
                </div>
                <div className="mt-2 text-3xl font-black text-white">{packageName}</div>
                <p className="mt-2 text-slate-400">
                  Complete the questionnaire to update this package recommendation.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-[2rem] border-white/10 bg-white/[0.04]">
            <CardContent className="p-6 md:p-8">
              <div className="mb-5 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="h-7 w-7 text-cyan-300" />
                  <div>
                    <h2 className="text-3xl font-black text-white">Your AI GrowthMap Report</h2>
                    <p className="text-slate-400">Copy and share the finished audit.</p>
                  </div>
                </div>

                <Button
                  onClick={copyReport}
                  variant="outline"
                  className="rounded-2xl border-white/15 bg-black/50 font-bold text-white hover:bg-white/10"
                >
                  <Clipboard className="mr-2 h-4 w-4" /> Copy My GrowthMap
                </Button>
              </div>

              <pre className="min-h-72 whitespace-pre-wrap rounded-2xl border border-white/10 bg-black/55 p-5 text-sm leading-7 text-slate-300">
                {reportText}
              </pre>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="border-y border-white/10 bg-slate-950 px-5 py-16 md:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-9 max-w-3xl">
            <h2 className="text-4xl font-black text-white">
              More than marketing. We build systems that scale.
            </h2>
            <p className="mt-4 text-lg leading-8 text-slate-300">
              Blacktop GrowthMap helps businesses see what is missing, what to fix first, and what growth route to take next.
            </p>
          </div>

          <div className="grid gap-5 md:grid-cols-4">
            {featureCards.map((card) => {
              const Icon = card.icon;
              return (
                <Card key={card.title} className="rounded-3xl border-white/10 bg-white/[0.04]">
                  <CardContent className="p-6">
                    <Icon className="mb-5 h-9 w-9 text-cyan-300" />
                    <h3 className="text-xl font-black text-white">{card.title}</h3>
                    <p className="mt-3 leading-7 text-slate-400">{card.text}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      <footer className="px-5 py-8 text-center text-sm text-slate-500 md:px-8">
        © 2026 Blacktop Syndicate. Blacktop GrowthMap™. Powered by Blacktop AI.
      </footer>
    </main>
  );
}
