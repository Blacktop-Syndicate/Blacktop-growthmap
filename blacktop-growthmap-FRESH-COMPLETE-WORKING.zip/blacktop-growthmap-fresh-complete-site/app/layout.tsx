import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Blacktop GrowthMap™",
  description: "Powered by Blacktop AI. AI business audits and growth roadmaps."
};

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
